<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UORDER_PAID extends Model
{
    protected $table = 'UORDER_PAID';
}
//???
