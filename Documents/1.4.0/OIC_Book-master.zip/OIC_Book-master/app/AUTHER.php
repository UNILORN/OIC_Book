<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AUTHER extends Model
{
    protected $table = 'AUTHER';
}
//ok
