<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PROUSER extends Model
{
    protected $table = 'PROUSER';
}
//ok
