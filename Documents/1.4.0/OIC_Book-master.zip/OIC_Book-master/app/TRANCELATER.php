<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TRANCELATER extends Model
{
    protected $table = 'TRANCELATER';
}
//ok
