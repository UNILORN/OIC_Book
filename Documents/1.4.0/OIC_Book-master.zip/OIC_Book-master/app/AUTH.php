<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AUTH extends Model
{
    protected $table = 'AUTH';
}
//ok
