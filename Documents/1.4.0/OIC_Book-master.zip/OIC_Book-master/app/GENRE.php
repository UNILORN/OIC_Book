<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GENRE extends Model
{
    protected $table = 'GENRE';
    protected $primaryKey = 'genre_id';
}
//ok
