@extends('/administer/admin_template')

@section('css','/admin/mailsend')
@section('title','発注メールフォーム')
@section('mail','class="active"')

@section('main')
    <h1 style="text-align: center">送信完了しました</h1>
@endsection