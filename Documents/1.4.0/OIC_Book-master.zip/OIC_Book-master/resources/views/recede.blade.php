@extends('template')
@section('title','recede')


@section('main')

@endsection
